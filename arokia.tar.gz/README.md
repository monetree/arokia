#coding Challange
        Author:soubhagya kumar pradhan
        created on : 17 may 2018

#Technology used:
        php
        mysql
        html
        css
        bootstrap
        javascript

#files included:
        index.php
        arokia.sql
        script.js
        style.css
        README.md
        .git

#git hub repository link:
        https://github.com/monetree/arokia

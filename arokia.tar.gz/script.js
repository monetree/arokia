function myFunction1(){
      r=confirm("By Cheking this your previus data will be erazed");
      if(r==true){
document.getElementById("one").checked = true;
      }
      if(r==false){
document.getElementById("one").checked = false;
      }
}

function myFunction2(){
      r=confirm("By Cheking this your previus data will be erazed");
      if(r==true){
document.getElementById("two").checked = true;
      }
      if(r==false){
document.getElementById("two").checked = false;
      }
}
